<div class="container-fluid mh90">
    <div class="col-md-2 ptb20">
        <div class="sidebar row">
            <ul class="nav nav-pills nav-stacked">
                <li role="presentation" class="<?php echo $sadmin?>"><a href="<?php echo base_url().'cms/manage/administrator'?>">Administrator</a></li>
                <li role="presentation" class="<?php echo $steacher?>"><a href="<?php echo base_url().'cms/manage/teacher'?>">Teacher</a></li>
                <li role="presentation" class="<?php echo $sstudent?>"><a href="<?php echo base_url().'cms/manage/student'?>">Student</a></li>
                <li role="presentation" class="<?php echo $slesson?>"><a href="<?php echo base_url().'cms/manage/lesson'?>">Lesson</a></li>
                <li role="presentation" class="<?php echo $ssubject?>"><a href="<?php echo base_url().'cms/manage/subject'?>">Subject</a></li>
            </ul>
        </div>
    </div>