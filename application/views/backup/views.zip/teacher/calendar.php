<script>

    $(document).ready(function() {
        $('#calendar').fullCalendar({
            defaultView: 'agendaWeek',
            events: [
                // events go here
            ],
            resources: [
                // resources go here
            ]
            // other options go here...
        });

    });
</script>
<style>

    #calendar {
        max-width: 900px;
        margin: 0 auto;
    }
</style>
<div class="container-fluid p20">
    <div id='calendar'></div>
</div>
