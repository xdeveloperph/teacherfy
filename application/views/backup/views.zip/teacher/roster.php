<div class="container-fluid">
    <div class="mh700">

        <div class="pt20">
            <a href="#" class="btn btn-success"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Add new student</a>
        </div>
        <div class="pt20">
            <?php if(!empty($error)){ ?>
                <div class="alert alert-danger" role="alert"><?php echo $error ?></div>
            <?php } ?>
            <?php if(!empty($success)){ ?>
                <div class="alert alert-success" role="alert"><?php echo $success ?></div>
            <?php } ?>
        </div>

        <table class="table">
            <thead>
            <tr>
                <th>Active Students</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Schedule Notification</th>
                <th>Account</th>
            </tr>
            </thead>
            <tbody>

            </tbody>
        </table>
    </div>

</div>
