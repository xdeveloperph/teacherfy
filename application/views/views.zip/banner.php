<div class="banner-container">
    <div class="p50">
        <div class="banner-head">
            <h1><strong>What would you like to learn today?</strong></h1>
            <h4>Search thousands of teachers for local and online lessons</h4>
        </div>
        <div>
            <form class="form-inline text-center">
                <div class="form-group banner-form-group">
                    <input type="text" class="banner-text-field" id="exampleInputName2" placeholder="Type of Lesson">
                    <input type="email" class="banner-text-field" id="exampleInputEmail2" placeholder="Street Address or Zip Code">
                    <input type="submit" class="banner-btn" id="exampleInputEmail2" value="Search for Your Teacher">

                </div>
            </form>
        </div>
    </div>
</div>