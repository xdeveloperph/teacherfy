        <footer>
            <div class="container">
                <small>� 2016 Teacherfy - Made by Seng Media LLC</small>
            </div>
        </footer>

    </body>

</html>