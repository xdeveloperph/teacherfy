<?php
error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');
class Teacher extends CI_Controller {

    public $content_data =array(
        'user' => '',
        'hdashboard' => '',
        'hcalendar' => '',
        'hprofile' => '',
        'hmanage' => '',
        'hroster' => '',
        'havailability' => '',
        'hearnings' => '',
        'sadmin' => '',
        'steacher' => '',
        'sstudent' => '',
        'slesson' => '',
        'ssubject' => '',
        'error' => '',
        'success' => '',

    );
    public function __construct()
    {
        parent::__construct();
        if(!isset($_SESSION['user'])){
            redirect(base_url(), false);
            die();
        }

        $this->content_data['user'] = $_SESSION['user'];

    }
    public function index()
    {
        $this->content_data['hdashboard'] ='active';
        $this->load->view('teacher/header',$this->content_data);
        $this->load->view('teacher/dashboard');
        $this->load->view('teacher/footer');
    }

    public function Dashboard()
    {
        $this->content_data['hdashboard'] ='active';
        $this->load->view('teacher/header',$this->content_data);
        $this->load->view('teacher/dashboard');
        $this->load->view('teacher/footer');
    }
    public function Calendar()
    {
        $this->load->model('CustomJoin');
        $this->load->model('students');
        $this->load->model('Lesson_schedule');

        if(isset($_POST['data'])){

            $ins_post=$_POST['data'];
            $ins_post['teacherid']=$this->content_data['user']['id'];
            $this->Lesson_schedule->Insert($ins_post);
        }

        $this->content_data['calendar'] = $this->CustomJoin->GetTeacherLessonSchedule($this->content_data['user']['id']);
        $this->content_data['subject'] = $this->CustomJoin->GetTeacherSubject($this->content_data['user']['id']);
        $this->content_data['student'] = $this->students->GetListofStudents($this->content_data['user']['id']);

        $this->load->view('teacher/header',$this->content_data);
        $this->load->view('teacher/calendar');
        $this->load->view('teacher/footer');
    }
    public function Availability()
    {
        $this->content_data['havailability'] ='active';
        $this->load->view('teacher/header',$this->content_data);
        $this->load->view('teacher/calendar');
        $this->load->view('teacher/footer');
    }
    public function Roster()
    {
        $this->load->model('students');
        if(isset($_POST['data'])){
            $ins_post=$_POST['data'];
            $ins_post['teacherid']=$this->content_data['user']['id'];
            $this->students->Insert($ins_post);
        }
        $this->content_data['result'] = $this->students->GetListofStudents($this->content_data['user']['id']);

        $this->content_data['hroster'] ='active';
        $this->load->view('teacher/header',$this->content_data);
        $this->load->view('teacher/roster');
        $this->load->view('teacher/footer');
    }
    public function logout()
    {
        session_destroy();
        redirect(base_url(), false);
    }
}
